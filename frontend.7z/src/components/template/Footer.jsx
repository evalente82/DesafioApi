import './Footer.css'
import React from 'react'

// eslint-disable-next-line import/no-anonymous-default-export
export default props =>
<footer className="footer">
        <span>
            Desafio Ateliware, 
            <strong> Endrigo Valente</strong>
        </span>
    </footer>