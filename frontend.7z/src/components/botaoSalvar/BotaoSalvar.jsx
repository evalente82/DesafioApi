
import React, { useEffect, useState } from 'react';
import {salvarRepositorysService} from '../../services/RepositorysService'


export default function BotaoSalvar(props) {
    //const [save, setSave] = useState({login:'', html_url:''})
    
    const [repositories, setRepositories] = useState([])
    useEffect(() =>{
        fetch('https://api.github.com/users/braziljs/repos')
        .then(response => response.json())
        .then(data => setRepositories(data))
    }, [])

    
    const data = repositories.map(repository =>{
        return(
            repository.login,
            repository.html_url
        )
    })
    


    // useEffect(() =>{
    //     setSave(props.data)
    // }, [props.data])


    function Salvar(){
        salvarRepositorysService(data.login, data.html_url)
        .then(result =>{
            if (props.Salvar) props.Salvar(result);
        })
    }
    return(
        <React.Fragment>
            <p><button type="button" class="btn btn-danger" onClick={Salvar} >Salvar Repositório</button></p>
        </React.Fragment>
    )
    
}