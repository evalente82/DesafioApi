/* eslint-disable no-unused-vars */
import React, { Component } from 'react'
import axios from 'axios'

const api = {
    basUrl: "https://api.github.com",
    client_id: "fcacebada7b04a77d66d",
    client_secret: "1d28fafa30333f18239cc47b6347abf5ff402ccf"
}

export default api